package com.example.android.todoapp.splashscreen;

public class SplashScreen {
}
